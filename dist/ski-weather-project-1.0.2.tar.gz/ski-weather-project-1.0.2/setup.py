from distutils.core import setup
setup(
    name = "ski-weather-project",
    packages = ["ski-weather-project"],
    version = "1.0.2",
    author = "Khrystyna Kubatska",
    author_email = "kubatska@ucu.edu.ua",
    url = "http://localhost",
    classifiers = [
        "Programming Language :: Python",
        "Programming Language :: Python :: 3"]
)